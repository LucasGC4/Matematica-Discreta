from typing import List
import pytest
import modular
from tests.test_imatlab import try_command

@pytest.mark.parametrize("a,b,salida_esperada",[
    (1,11,[2,3,5,7]),
    (8,10,[]),
    (-3,0,[]),
    (2,3,[2]),
    (-100,-2,[]),
    (1,2,[])
])
def test_lista_primos_basico(a: int, b:int, salida_esperada: List[int]) -> None:
    assert(modular.lista_primos(a,b)==salida_esperada)

@pytest.mark.parametrize("a,b,salida_esperada",[
    (1,11,"2, 3, 5, 7"),
    (8,10,"NE"),
    (-3,0,"NE"),
    (2,3,'2'),
    (-100,-2,"NE"),
    (1,2,"NE")
])
def test_lista_primos_imatlab(a:int, b:int, salida_esperada: str) -> None:
    try_command(f"primos({a},{b})",salida_esperada)