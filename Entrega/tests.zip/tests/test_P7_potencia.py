import pytest
import modular
from tests.test_imatlab import try_command

@pytest.mark.parametrize("base,exp,p,salida_esperada",[
    (2,3,7,1),
    (1,6,7,1),
    (-2,3,7,6),
    (-2,0,7,1),
    (0,3,9,0)   
])
def test_potencia_mod_p_basico(base: int, exp:int, p:int, salida_esperada: int) -> None:
    assert(modular.potencia_mod_p(base,exp,p)==salida_esperada)


def test_potencia_mod_p_cero():
    """ Este test comprueba que, en los casos esperados,
    realmente se lanza la excepción esperada"""
    with pytest.raises(ZeroDivisionError):
        modular.potencia_mod_p(2,3,0)
    with pytest.raises(ZeroDivisionError):
        modular.potencia_mod_p(0,0,7)

@pytest.mark.parametrize("base,exp,p,salida_esperada",[    
    (2,3,7,"1"),
    (0,0,0,"NE"),
    (-2,3,7,'6'),
    (-2,0,7,'1'),
    (0,3,9,'0'),
    (0,-3,9,"NE")
])
def test_potencia_imatlab(base: int, exp:int, p:int, salida_esperada: str) -> None:
    try_command(f"pow({base},{exp},{p})",salida_esperada)