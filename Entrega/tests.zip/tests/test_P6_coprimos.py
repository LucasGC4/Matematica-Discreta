import pytest
import modular
from tests.test_imatlab import try_command

@pytest.mark.parametrize("a,b,salida_esperada",[
    (14,20,False),
    (14,15,True),
    (3,4,True),
    (-3,71,True),
    (0,72,False),
    (0,1,True)

])
def test_coprimos_basico(a: int, b:int, salida_esperada: bool) -> None:
    assert(modular.coprimos(a,b)==salida_esperada)


@pytest.mark.parametrize("a,b,salida_esperada",[    
    (14,20,"No"),
    (14,15,"Sí"),
    (3,4,"Sí"),
    (-3,71,"Sí"),
    (0,72,"No"),
    (0,1,"Sí")
])
def test_coprimos_imatlab(a:int, b: int, salida_esperada: str) -> None:
    try_command(f"coprimos({a},{b})",salida_esperada)